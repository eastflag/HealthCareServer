package com.healthcare.biz.common;

public class SectionCode {
	public final static String Weight = "Weight"; 
	public final static String Height = "Height";
	public final static String BMI = "BMI";
}
