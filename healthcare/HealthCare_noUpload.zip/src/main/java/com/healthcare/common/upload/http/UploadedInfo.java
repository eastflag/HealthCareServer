package com.healthcare.common.upload.http;
public class UploadedInfo {
	public String original = "";
	public String renames = "";
	public long size = -1;
} 