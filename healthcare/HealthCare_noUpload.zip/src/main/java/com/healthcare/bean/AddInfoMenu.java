package com.healthcare.bean;


/**
 * @since 2015.04.16
 * @author Tharaud Class Add
 * 추가정보메뉴 화면
 *
 */
public class AddInfoMenu {
	String addMenu=null;

	public String getAddMenu() {
		return addMenu;
	}

	public void setAddMenu(String addMenu) {
		this.addMenu = addMenu;
	}
	
	

}
